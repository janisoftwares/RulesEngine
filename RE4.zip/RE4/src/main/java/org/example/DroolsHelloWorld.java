package org.example;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DroolsHelloWorld {
    public static void main(String[] args) {
        try {
            // 🔹 DEBUG: Check if rules.drl exists in classpath
            InputStream rulesStream = DroolsHelloWorld.class.getClassLoader().getResourceAsStream("org/example/rules.drl");
            if (rulesStream == null) {
                System.err.println("ERROR: rules.drl file NOT FOUND in classpath!");
                return;
            } else {
                System.out.println("SUCCESS: rules.drl file FOUND in classpath.");
            }
            InputStream kmoduleStream = DroolsHelloWorld.class.getClassLoader().getResourceAsStream("META-INF/kmodule.xml");
            if (kmoduleStream == null) {
                System.err.println("ERROR: kmodule.xml NOT FOUND in classpath!");
            } else {
                System.out.println("SUCCESS: kmodule.xml FOUND in classpath.");
            }
            KieServices kieServices = KieServices.Factory.get();
            KieContainer kieContainer = kieServices.getKieClasspathContainer();
            System.out.println("Loaded KIE container");
            KieSession kieSession = kieContainer.newKieSession("ksession-rules");
            System.out.println("session started");
            System.out.println("==== Drools Hello World ====");
            // Insert an object into the session
            String message = "Hello, Drools!";
            if (kieSession != null) {
                System.out.println("KieSession initialized automatically.");
            } else {
                // Handle the case where kieSession is null
                System.out.println("KieSession is not initialized automatically because rules.drl not found");
                System.out.println("Loading KieSession manually.");
                // 2️⃣ Create KieFileSystem
                KieFileSystem kfs = kieServices.newKieFileSystem();
                // 3️⃣ Load a DRL file manually (from file system)
                String drlPath = "src/main/resources/org/example/rules.drl"; // Path to .drl file
                String drlContent = new String(Files.readAllBytes(Paths.get(drlPath)), StandardCharsets.UTF_8);
                // 4️⃣ Write the DRL file into KieFileSystem
                kfs.write("src/main/resources/org/example/rules.drl", drlContent);
                // 5️⃣ Build the Kie module
                KieBuilder kieBuilder = kieServices.newKieBuilder(kfs).buildAll();
                if (kieBuilder.getResults().hasMessages(org.kie.api.builder.Message.Level.ERROR)) {
                    System.err.println("Rule compilation errors: " + kieBuilder.getResults().getMessages());
                    return;
                }
                // 6️⃣ Get KieContainer and create KieSession
                kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
                kieSession = kieContainer.newKieSession();
            }
            kieSession.insert(message);
            System.out.println("Message inserted.");
            // Fire all rules
            kieSession.fireAllRules();
            // Close the session
            kieSession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}